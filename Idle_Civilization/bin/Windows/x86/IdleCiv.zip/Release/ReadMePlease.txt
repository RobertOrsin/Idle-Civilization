Welcome to IDLE-Civ pre Alpha
=============================

this version is made to test the balance between production and consumption.

edit the nessecary values inside the GameValues.txt to experiment with different settings.

you can also edit the costs of different upgrades in the config.xml

There are issues in the programm which lead to a exception. f.e. do not click on tiles on the sides of the map.

Please send me infos over any other type of exception :)


Included features:
	- Build Citys
		o only on gras
	- Create Poeple
	- Deploy people to differnt works
	- Add tiles to your city
	- Conquer tiles from enemy terretories
	
Stuff that sucks but is still there:
	- Creating army resets army-worker and costs no other ressources
		--> you can cheat to get army
		--> using no other ressources for this is not good
	
